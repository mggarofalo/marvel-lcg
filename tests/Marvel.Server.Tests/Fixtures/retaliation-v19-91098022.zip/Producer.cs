using System.IO.Compression;
using System.Text.Json;
using Marvel.Server;
using Marvel.Session;
using Marvel.Protocol;
using Marvel.Rules.Play;
var repo="C:/Users/mggar/Source/marvel-lcg-630-predecessor";
var output=Path.Combine(Path.GetTempPath(),"marvel635-v19-artifacts");Directory.CreateDirectory(output);
var factory=DatasetGameFactory.Load(repo);
if(factory.Compatibility.ReplayContract!="engine-replay-v19")throw new Exception("wrong predecessor");
EngineResponse Check(EngineResponse r){if(r.Error is {} e)throw new Exception(e.Code+": "+e.Message);return r;}
var sessionDir=Path.Combine(output,"black-panther");Directory.CreateDirectory(sessionDir);
var sessions=new FileSessionStore(Path.Combine(sessionDir,"sessions"));
var engine=new EngineHost(factory,store:sessions);
var current=Check(engine.Exchange(EngineRequest.OpenGame("open","v19-bp",new("rhino",["black_panther"],null,700))));
var capability=current.Capability!;var options=new JsonSerializerOptions{PropertyNamingPolicy=JsonNamingPolicy.SnakeCaseLower};int count=0;
foreach(var line in File.ReadLines(Path.Combine(Path.GetTempPath(),"cap635-predecessor-bp-rhino.jsonl"))){using var doc=JsonDocument.Parse(line);var p=doc.RootElement;if(p.GetProperty("type").GetString()!="step")continue;
 var selector=p.GetProperty("decision").Deserialize<DecisionSelector>(options)!;
 var durable=new DurableDecision(DurableDecision.SimulationActor(current.Prompt!,selector),selector,p.GetProperty("targets").Deserialize<int[]>()!,p.GetProperty("resources").Deserialize<int[]>()!,p.GetProperty("values").Deserialize<Dictionary<string,long>>()!,p.GetProperty("allocations").Deserialize<ResourceAllocation[]>(options)!);
 current=Check(engine.Exchange(EngineRequest.ResolveGame("step-"+count++,"v19-bp",capability,durable.Resolve(current.Prompt!),current.Revision)));
}
File.WriteAllText(Path.Combine(sessionDir,"access.json"),JsonSerializer.Serialize(new{game="v19-bp",capability}));
File.WriteAllBytes(Path.Combine(sessionDir,"resumed-wire-response.json"),EngineJson.Write(Check(new EngineHost(factory,store:sessions).Exchange(EngineRequest.SyncGame("restart","v19-bp",capability)))));
Console.WriteLine("Actual v20 BP published and restarted: "+count+" decisions");
