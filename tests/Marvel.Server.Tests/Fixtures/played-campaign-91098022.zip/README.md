# MARVEL-634 genuine predecessor campaign fixture

Generated exclusively with untouched predecessor `91098022d37ce739dd2880e8964b40ee3675eeb3` (engine-replay-v19), canonical datasets and legal engine-offered decisions. Temporary policy/harness sources are included. No synthetic boards, victories, campaign outcomes, or altered runtime code were used.

Spider-Man published starter, standard campaign and standard scenarios, root seed504. Ten Crossbones attempts (last won), two Absorbing Man attempts (last won), then active Taskmaster attempt12 with five accepted decisions. 781 terminal decisions plus5 active. Crossbones carried experimental weapon04073; tech04155 was earned then genuinely consumed and remains in RemovedCardKeys; condition04159a is owned with HP bonus2. DelayCounters0; no nonzero-delay or expert-mode coverage claimed.

`published/campaign.json`: canonical capability-free CampaignSave.
`published/campaigns/`: exact original FileCampaignStore generations and current manifest (writer lock files omitted).
`published/access.json`: exact returned owner/game capabilities and IDs for this generated test campaign.
`published/owner-wire-response.json` and `resumed-wire-response.json`: actual EngineJson responses from final fresh-process owner/game sync. Initial creation response was not retained; authority is retained in access.json and original store receipts.
`published/campaign-transfer.txt`: exact CampaignHost export string for import tests.
`control/continuation-request.json`, `continuation-response.json`, `continuation-decision.json`: next legal decision and actual expected old-runtime response, produced on an independent COPY after the frozen five-decision active prefix. Original fixture was not advanced.
`miner/winner-504-1.json`: independently generated full JournalStep records (prompts, choices, events, RNG count, digest) for all781 terminal decisions and engine-inspected outcomes/reward choices.
`source/`: generator, production-host publisher, independent verifier, continuation control and policy.
`evidence/`: publication, independent verification, final restart and continuation logs.
`provenance.json`: exact revision, dataset/source hashes and deterministic policy seeds.

Production publication submitted the same durable choices through CampaignHost and FileCampaignStore. Fresh-process verification restored every campaign proof and attempt; additionally all781 full terminal JournalSteps matched the independent miner exactly (Result field absent from the miner, terminal outcomes independently inspected). Active5 digest/RNG matched independent real execution. Another fresh process restored/resumed the final artifact. No application-upgrade claim is made here; v20 upgrade tests must use copies, preserving original evidence.

Reproduction: build source/Miner.csproj after replacing absolute paths with an untouched checkout of the named predecessor and policy source path. Run miner seeds500–563 (stops at504), publish winner-504-1.json, verify twice. Run control only against a copy of published. Operational IDs/capabilities are intentionally freshly generated; gameplay traces are deterministic.
