using System.Text.Json;
using Marvel.Server;
using Marvel.Protocol;
using Marvel.Rules.Campaign;
using Marvel.Rules.Setup;
using Marvel.Content.Setup;
using Marvel.Core.Random;
using Marvel.Session;
using Marvel.Sim;
if(args.Length>0 && args[0]=="control") { ContinuationControl.Run(args[1]); return; }
if(args.Length>0 && args[0]=="verify") { Verifier.Run(args[1]); return; }
if(args.Length>0 && args[0]=="publish") { Publisher.Run(args[1]); return; }
var root = @"C:/Users/mggar/Source/marvel-lcg-630-predecessor";
var factory = DatasetGameFactory.Load(root);
var definition = factory.CampaignDefinition!;
var setup = SetupCatalog.Parse(File.ReadAllText(root + "/datasets/setup/setup.json"));
var hero = setup.Hero("spider_man");
var deck = new PlayerDeckRecipe([..hero.HeroDeck.Concat(hero.PlayerDeck)]);
uint start = args.Length > 0 ? uint.Parse(args[0]) : 1;
uint count = args.Length > 1 ? uint.Parse(args[1]) : 64;
for(uint seed=start;seed<start+count;seed++) {
 var state=CampaignRules.Create(definition,[new("spider_man",deck,factory.CampaignBaseHitPoints("spider_man"))],false,seed);
 var records=new List<object>();
 try {
  for(int attempt=0;attempt<24 && (int)state.Stage<2;attempt++) {
   int stage=(int)state.Stage;
   uint policySeed=266+seed+(uint)stage*1000+(uint)attempt*17;
   var spec=new GameSpecification(definition.Scenarios[(int)state.Stage].Standard,["spider_man"],null,CampaignSeed.ForAttempt(seed,state.Stage,state.Attempt),[deck],CampaignRules.Setup(state));
   var opened=factory.Create(spec);var game=opened.Game;
   var policy=new ActingPolicy(game.State.Facts,[new MersenneTwister(policySeed).NextUInt32()]);
   state=CampaignRules.Start(state);var steps=new List<JournalStep>();
   for(int step=0; game.Pending is {} prompt && step<800; step++) {
    var answer=policy.Answer(game);var durable=DurableDecision.From(DurableDecision.SimulationActor(prompt,answer),prompt,answer);
    var before=PromptRecord.From(prompt);var resolved=game.Resolve(durable.Resolve(prompt));policy.DecisionResolved();
    steps.Add(new(before,durable,[..resolved.Events.Select(JournalJson.Event)],game.State.Random.Generator.WordsConsumed,game.State.Digest().Fingerprint()));
   }
   var progress=factory.InspectCampaign(game);
   Console.WriteLine($"seed={seed} stage={stage} result={game.State.Result} steps={steps.Count} round={game.Round}");
   if(progress.Outcome is not {} outcome) break;
   state=CampaignProgressRules.Apply(state,progress);state=CampaignOutcomeRules.Finish(state,definition,outcome);
   var rewards=new List<string?>();
   while(CampaignRewardRules.Choice(state,definition) is {} reward) {var key=reward.Options[0].Key;rewards.Add(key);state=CampaignRewardRules.Choose(state,definition,reward.Seat,key);}
   bool retry=state.Phase==CampaignPhase.Retry;
   if(retry) state=CampaignRules.Retry(state);
   records.Add(new {spec,policySeed,steps,outcome,rewards,retry,state});
   File.WriteAllText(Path.Combine(AppContext.BaseDirectory,$"winner-{seed}-{stage}.json"),JsonSerializer.Serialize(records));
   if((int)state.Stage==2) {Console.WriteLine($"COMPLETE seed={seed}");return;}
  }
 } catch(Exception ex) {Console.WriteLine($"seed={seed} failed={ex.GetType().Name}: {ex.Message}");}
}
