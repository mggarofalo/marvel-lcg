using System.Text.Json;
using Marvel.Server;
using Marvel.Protocol;
using Marvel.Session;
using Marvel.Rules.Setup;
using Marvel.Rules.Campaign;
internal static class Publisher {
 public static void Run(string input) {
 var factory=DatasetGameFactory.Load(@"C:/Users/mggar/Source/marvel-lcg-630-predecessor");
 using var data=JsonDocument.Parse(File.ReadAllText(input));
 var first=data.RootElement[0].GetProperty("spec").Deserialize<GameSpecification>()!;
 string directory=Path.Combine(Path.GetDirectoryName(input)!,"published-504"); Directory.CreateDirectory(directory);
 using var store=new FileCampaignStore(Path.Combine(directory,"campaigns"));
 var host=new CampaignHost(factory,store,new MemorySessionStore());
 var created=Check(host.Exchange(new(EngineProtocol.Version,"create",EngineProtocol.Campaign,"Predecessor legal campaign 504",Entry:EntryClaim.Create()) {Campaign=new("create"){Product=factory.CampaignDefinition!.Product,Seed=504,Heroes=["spider_man"],Decks=[first.PlayerDecks![0]]}}));
 string owner=created.Capability!, id=created.Campaign!.Id; int serial=0;
 EngineResponse Command(string action, string? choice=null) {
 var latest=Check(host.Exchange(new(EngineProtocol.Version,$"sync-{serial++}",EngineProtocol.Campaign,id,Capability:owner){Campaign=new("sync")}));
 return Check(host.Exchange(new(EngineProtocol.Version,$"{action}-{serial++}",EngineProtocol.Campaign,id,Capability:owner,ExpectedRevision:latest.Campaign!.Revision,Entry:action=="start"?EntryClaim.Create():null){Campaign=new(action){Choice=choice,Seat=0}})); }
 foreach(var record in data.RootElement.EnumerateArray()) {
 var current=Command("start");string cap=current.Capability!, gameId=current.GameId;
 var steps=record.GetProperty("steps").Deserialize<List<JournalStep>>()!;
 foreach(var step in steps) {
 if(current.Prompt is null) throw new Exception("premature terminal");
 if(CampaignSaveJson.Canonical(PromptRecord.From(current.Prompt))!=CampaignSaveJson.Canonical(step.Prompt)) throw new Exception("prompt mismatch");
 current=Check(host.Exchange(EngineRequest.ResolveGame($"resolve-{serial++}",gameId,cap,step.Decision.Resolve(current.Prompt),current.Revision)));
 }
 foreach(var reward in record.GetProperty("rewards").EnumerateArray()) Command("reward",reward.GetString());
 if(record.TryGetProperty("retry",out var retry) && retry.GetBoolean()) Command("retry");
 Console.WriteLine($"published attempt steps={steps.Count} phase={store.Load()[0].Campaign!.Save.State.Phase}");
 }
 var active=Command("start");
 File.WriteAllText(Path.Combine(directory,"access.json"),JsonSerializer.Serialize(new {owner,id,game=active.GameId,capability=active.Capability}));
 var saved=store.Load()[0].Campaign!.Save;
 File.WriteAllBytes(Path.Combine(directory,"campaign.json"),CampaignSaveJson.Write(saved));
 var restarted=new CampaignHost(factory,store,new MemorySessionStore());
 var resume=Check(restarted.Exchange(EngineRequest.SyncGame("restart-resume",active.GameId,active.Capability!)));
 if(resume.Prompt is null)throw new Exception("active attempt did not resume");
 Console.WriteLine($"VERIFIED attempts={saved.Attempts.Length} stage={saved.State.Stage} phase={saved.State.Phase} journal={saved.Journal.Length} prompt={resume.Prompt.Asking}");
 }
 private static EngineResponse Check(EngineResponse response) {if(response.Error is {} error)throw new Exception($"{response.RequestId}: {error.Code} {error.Message}");return response;}
}
