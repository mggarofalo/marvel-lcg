using Marvel.Core.Random;
using Marvel.Rules.Play;
using Marvel.Rules.Prompts;
using Marvel.Rules.State;

namespace Marvel.Sim;

/// <summary>A deterministic research policy that plays cards and attacks.</summary>
internal sealed class ActingPolicy(ICardFacts facts, IReadOnlyList<uint> seatSeeds)
{
    public const string Name = "campaign-research";
    public const int Version = 1;
    public const string Visibility = "full_state";

    private readonly IReadOnlyList<EngineRandom> random =
        [.. seatSeeds.Select(seed => new EngineRandom(seed))];
    private PolicyMetrics pending = new(0, 0, 0, 0);

    public int CardsPlayed { get; private set; }
    public int PlayerAttacks { get; private set; }
    public int Payments { get; private set; }
    public int ResourceAbilitiesUsed { get; private set; }

    public PolicyMetrics Metrics => new(
        CardsPlayed, PlayerAttacks, Payments, ResourceAbilitiesUsed);

    public Decision Answer(Game game)
    {
        ArgumentNullException.ThrowIfNull(game);
        pending = new PolicyMetrics(0, 0, 0, 0);
        var asked = game.Pending
            ?? throw new InvalidOperationException("a finished game has no prompt to answer");
        var world = game.State;

        if (IsMulligan(asked))
        {
            return Taking(
                game,
                asked.Affordances.Single(option => option.IsLegal),
                [],
                []);
        }

        if (AnswerQuestion(game, asked) is { } answer)
        {
            return answer;
        }
        if (asked.Asking == Question.Opportunity)
        {
            foreach (var offered in asked.Affordances.Where(option => option.IsLegal))
                if (Payment(offered) is { } payment)
                    return Taking(game, offered, payment);
        }

        var ending = asked.Affordances.FirstOrDefault(option =>
            option.IsLegal
            && string.Equals(option.Verb, Game.EndPhaseVerb, StringComparison.Ordinal));
        if (ending is not null)
        {
            return Taking(game, ending, [], Excess(world, asked.Player));
        }

        if (asked.Asking == Question.TurnOption)
        {
            return Turn(game, asked);
        }

        return asked.Cancellable
            ? Decision.Decline
            : Taking(game, asked.Affordances.First(option => option.IsLegal), []);
    }

    private static bool IsMulligan(Prompt prompt) => prompt.Affordances.Any(option =>
        string.Equals(option.Verb, Game.ResolveMulligans, StringComparison.Ordinal));

    private static bool IsChoiceQuestion(Question question) =>
        question is Question.Element or Question.Option or Question.Order;

    private Decision? AnswerQuestion(Game game, Prompt asked)
    {
        if (asked.Asking == Question.Defender)
        {
            List<Affordance> defenders = asked.Affordances.Where(option => option.IsLegal).ToList();
            return defenders.Count == 0
                ? Decision.Decline
                : Taking(game, random[asked.Player].Choice(defenders), []);
        }
        if (!IsChoiceQuestion(asked.Asking))
        {
            return null;
        }
        List<Affordance> choices = asked.Affordances.Where(option => option.IsLegal).ToList();
        Affordance choice = random[asked.Player].Choice(choices);
        return Taking(game, choice, Payment(choice) ?? []);
    }

    public void DecisionResolved()
    {
        CardsPlayed += pending.CardsPlayed;
        PlayerAttacks += pending.PlayerAttacks;
        Payments += pending.Payments;
        ResourceAbilitiesUsed += pending.ResourceAbilitiesUsed;
        pending = new PolicyMetrics(0, 0, 0, 0);
    }

    private Decision Turn(Game game, Prompt asked)
    {
        var world = game.State;
        var seat = world.Seats[asked.Player];
        bool hero = Forms.In(world, seat, facts, Forms.Hero);

        if (OpeningAction(game, asked, seat, hero) is { } opening)
        {
            return opening;
        }
        if (PayableAction(game, asked, world) is { } action)
        {
            return action;
        }
        if (PlayableCard(game, asked) is { } play)
        {
            return play;
        }

        long threat = world.TheCardIn(DeckType.MainSchemesArea)
            ?.Tokens.GetValueOrDefault("k_threat") ?? 0;
        string preferredPower = threat >= 3
            ? BasicPowers.ThwartVerb
            : BasicPowers.AttackVerb;
        var power = Find(asked, preferredPower)
            ?? Find(asked, BasicPowers.ThwartVerb)
            ?? Find(asked, BasicPowers.AttackVerb);

        return power is null ? Decision.Decline : Taking(game, power, []);
    }

    private Decision? OpeningAction(Game game, Prompt asked, Seat seat, bool hero)
    {
        long remaining = ActingHealth(game.State, asked.Player);
        long maximum = DamagePlacement.Health(game.State, facts, seat.IdentityCard);
        if (hero)
        {
            if (remaining <= 4 && Find(asked, Game.ChangeForm) is { } retreat)
                return Taking(game, retreat, []);
            return null;
        }
        if (remaining <= maximum - 3 && Find(asked, BasicPowers.RecoverVerb) is { } recover)
            return Taking(game, recover, []);
        if (ResourceAbilityPlay(asked, seat.IdentityCard.ObjectId) is { } resourcePlay)
        {
            return Taking(game, resourcePlay.Option, resourcePlay.Payment);
        }
        Affordance? change = Find(asked, Game.ChangeForm);
        return change is null ? null : Taking(game, change, []);
    }

    private Decision? PayableAction(Game game, Prompt asked, World world)
    {
        Affordance? action = asked.Affordances.OrderByDescending(option => Priority(game, option)).FirstOrDefault(option =>
            option.IsLegal
            && string.Equals(option.Verb, Game.ActionVerb, StringComparison.Ordinal)
            && ActingHealth(world, option.AnchorPlayer) > 1
            && Payment(option) is not null);
        IReadOnlyList<int>? payment = action is null ? null : Payment(action);
        return action is null || payment is null ? null : Taking(game, action, payment);
    }

    private Decision? PlayableCard(Game game, Prompt asked)
    {
        Affordance? play = asked.Affordances.OrderByDescending(option => Priority(game, option)).FirstOrDefault(option =>
            option.IsLegal
            && string.Equals(option.Verb, CardPlay.Verb, StringComparison.Ordinal)
            && Payment(option) is not null);
        return play is null ? null : Taking(game, play, Payment(play)!);
    }

    private int Priority(Game game, Affordance option)
    {
        if (option.AnchorId < 0 || option.AnchorId >= game.State.Cards.Count)
            return 0;
        var card = game.State.Cards[option.AnchorId];
        return card.FaceId switch
        {
            "01005" => 100,
            "01003" => 80,
            "01002" => 70,
            "01007" => 60,
            "01013" => 100,
            _ => facts.Kind(card.FaceId) == CardKind.Ally ? 50 : 0,
        };
    }

    private Decision Taking(
        Game game,
        Affordance option,
        IReadOnlyList<int> payment,
        IReadOnlyList<int>? targets = null)
    {
        var world = game.State;
        bool eventInHand = string.Equals(option.Verb, Game.ActionVerb, StringComparison.Ordinal)
            && option.AnchorPlayer >= 0
            && world.Seats[option.AnchorPlayer].Hand.Cards.Any(
                card => card.ObjectId == option.AnchorId)
            && facts.Kind(world.Cards[option.AnchorId].FaceId) == CardKind.Event;
        if (string.Equals(option.Verb, CardPlay.Verb, StringComparison.Ordinal) || eventInHand)
        {
            pending = pending with { CardsPlayed = pending.CardsPlayed + 1 };
        }

        if (string.Equals(option.Verb, BasicPowers.AttackVerb, StringComparison.Ordinal))
        {
            pending = pending with { PlayerAttacks = pending.PlayerAttacks + 1 };
        }

        if (payment.Count > 0)
        {
            pending = pending with { Payments = pending.Payments + 1 };
            var cardsInHands = world.Seats
                .SelectMany(seat => seat.Hand.Cards)
                .Select(card => card.ObjectId)
                .ToHashSet();
            pending = pending with
            {
                ResourceAbilitiesUsed = pending.ResourceAbilitiesUsed
                    + payment.Count(id => !cardsInHands.Contains(id)),
            };
        }

        var values = Values(option);
        return Decision.Take(
            option.Id,
            targets ?? Targets(world, option),
            payment,
            values,
            Allocations(option, payment, values));
    }

    private static Dictionary<string, long> Values(Affordance option) =>
        option.CostOptions
            .SelectMany(cost => cost.VariableRequests)
            .ToDictionary(
                variable => variable.Name,
                variable => variable.Min,
                StringComparer.Ordinal);

    private static IReadOnlyList<ResourceAllocation> Allocations(
        Affordance option,
        IReadOnlyList<int> payment,
        IReadOnlyDictionary<string, long> values) =>
        option.CostOptions
            .Select(cost => ResourcePayment.Allocate(cost, payment, values))
            .FirstOrDefault(allocation => allocation is not null)
        ?? [];

    private static Affordance? Find(Prompt asked, string verb) =>
        asked.Affordances.FirstOrDefault(option =>
            option.IsLegal && string.Equals(option.Verb, verb, StringComparison.Ordinal));

    private long ActingHealth(World world, int player)
    {
        var identity = world.Seats[player].IdentityCard;
        return DamagePlacement.Health(world, facts, identity) - identity.Damage;
    }

    private static (Affordance Option, IReadOnlyList<int> Payment)? ResourceAbilityPlay(
        Prompt asked,
        int identity)
    {
        foreach (var option in asked.Affordances.Where(option =>
                     option.IsLegal
                     && string.Equals(option.Verb, CardPlay.Verb, StringComparison.Ordinal)))
        {
            if (Payment(option) is [var source] payment && source == identity)
            {
                return (option, payment);
            }
        }

        return null;
    }

    private static IReadOnlyList<int> Targets(World world, Affordance option)
    {
        if (option.Targets is not { } wanted)
        {
            return [];
        }

        if (wanted.IsGrouped && wanted.Groups is { Count: > 0 } groups)
        {
            return groups[0];
        }

        var selected = wanted.Legal.Take(wanted.Min).ToList();
        int villain = world.TheCardIn(DeckType.VillainArea)?.ObjectId ?? -1;
        if (wanted.Min == 1 && wanted.Legal.Contains(villain))
        {
            selected[0] = villain;
        }

        return selected;
    }

    private static IReadOnlyList<int> Excess(World world, int player)
    {
        var seat = world.Seats[player];
        long limit = PhaseEnd.HandSize(world, seat, facts: world.Facts);
        return [.. seat.Hand.Cards
            .Take(Math.Max(0, seat.Hand.Cards.Count - (int)limit))
            .Select(card => card.ObjectId)];
    }

    private static IReadOnlyList<int>? Payment(Affordance option) =>
        PolicyPaymentSelection.Payment(option);
}
