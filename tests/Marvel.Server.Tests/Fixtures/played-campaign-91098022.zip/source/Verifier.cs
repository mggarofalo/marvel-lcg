using System.Text.Json;
using Marvel.Server;
using Marvel.Protocol;
using Marvel.Session;
internal static class Verifier {
 public static void Run(string directory) {
 var factory=DatasetGameFactory.Load(@"C:/Users/mggar/Source/marvel-lcg-630-predecessor");
 using var store=new FileCampaignStore(Path.Combine(directory,"campaigns"));
 var host=new CampaignHost(factory,store,new MemorySessionStore());
 using var access=JsonDocument.Parse(File.ReadAllText(Path.Combine(directory,"access.json")));var a=access.RootElement;
 var response=host.Exchange(EngineRequest.SyncGame("fresh-process-resume",a.GetProperty("game").GetString()!,a.GetProperty("capability").GetString()!));
 if(response.Error is not null || response.Prompt is null)throw new Exception("Fresh process did not resume");
 var save=store.Load()[0].Campaign!.Save;
 using var mine=JsonDocument.Parse(File.ReadAllText(Path.Combine(Path.GetDirectoryName(directory)!,"winner-504-1.json")));
 int total=0,index=0;
 foreach(var attempt in mine.RootElement.EnumerateArray()) {
 var expected=attempt.GetProperty("steps").Deserialize<List<JournalStep>>()!;
 var actual=save.Attempts[index++].Units.SelectMany(unit=>unit.Decisions).ToArray();
 if(expected.Count!=actual.Length)throw new Exception("count mismatch");
 for(int n=0;n<actual.Length;n++) {
 var x=actual[n] with {Result=null}; var y=expected[n] with {Result=null};
 if(CampaignSaveJson.Canonical(x)!=CampaignSaveJson.Canonical(y))throw new Exception($"journal mismatch attempt{index} step{n}");total++;
 }
 }
 if(save.Attempts.Length!=index+1 || save.State.Stage!=Marvel.Rules.Campaign.CampaignStage.Taskmaster)throw new Exception("campaign progression mismatch");
 if(save.Attempts[^1].Units.Count==0) {
 var setup=save.Attempts[^1].Setup;
 var local=factory.Create(new(setup.Scenario,setup.Heroes,setup.ModularSets,setup.Seed,setup.PlayerDecks,setup.Campaign)).Game;
 var policy=new Marvel.Sim.ActingPolicy(local.State.Facts,[new Marvel.Core.Random.MersenneTwister(504266).NextUInt32()]);
 for(int step=0;step<5;step++) {
 var prompt=local.Pending!;var answer=policy.Answer(local);var durable=DurableDecision.From(DurableDecision.SimulationActor(prompt,answer),prompt,answer);
 _=local.Resolve(durable.Resolve(prompt));policy.DecisionResolved();
 response=host.Exchange(EngineRequest.ResolveGame($"active-{step}",a.GetProperty("game").GetString()!,a.GetProperty("capability").GetString()!,durable.Resolve(response.Prompt!),response.Revision));
 if(response.Error is not null)throw new Exception(response.Error.Code);
 }
 save=store.Load()[0].Campaign!.Save;
 var last=save.Attempts[^1].Units.SelectMany(unit=>unit.Decisions).Last();
 if(last.StateFingerprint!=local.State.Digest().Fingerprint() || last.RngWords!=local.State.Random.Generator.WordsConsumed)throw new Exception("active digest/RNG mismatch");
 File.WriteAllBytes(Path.Combine(directory,"campaign.json"),CampaignSaveJson.Write(save));
 Console.WriteLine("Committed 5 legal Taskmaster decisions through predecessor host");
 }
 File.WriteAllBytes(Path.Combine(directory,"resumed-wire-response.json"),EngineJson.Write(response));
 var ownerReply=host.Exchange(new(EngineProtocol.Version,"owner-sync",EngineProtocol.Campaign,a.GetProperty("id").GetString()!,Capability:a.GetProperty("owner").GetString()!){Campaign=new("sync")});
 if(ownerReply.Error is not null)throw new Exception("owner did not resume");
 File.WriteAllBytes(Path.Combine(directory,"owner-wire-response.json"),EngineJson.Write(ownerReply));
 var exported=host.Exchange(new(EngineProtocol.Version,"export",EngineProtocol.Campaign,a.GetProperty("id").GetString()!,Capability:a.GetProperty("owner").GetString()!){Campaign=new("export")});
 if(exported.Error is not null || exported.CampaignTransfer is null)throw new Exception("export failed");
 File.WriteAllText(Path.Combine(directory,"campaign-transfer.txt"),exported.CampaignTransfer);
 Console.WriteLine($"FRESH PROCESS VERIFIED predecessor={save.Compatibility} completedAttempts={index} exactJournalSteps={total} active={save.State.Stage} phase={save.State.Phase}");
 }
}
