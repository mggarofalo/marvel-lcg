using Marvel.Server;
using Marvel.Session;
using Marvel.Protocol;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
internal static class Diagnostic {
 public static void Run(string directory) {
  AppDomain.CurrentDomain.FirstChanceException += (_, e) => { if (e.Exception is ReplayDivergenceException or SessionSaveException or ArgumentException or InvalidOperationException) Console.Error.WriteLine(e.Exception); };
  var factory=DatasetGameFactory.Load(@"C:/Users/mggar/Source/marvel-lcg-630-predecessor");
  using var store=new FileCampaignStore(Path.Combine(directory,"campaigns"));
  var original=store.Load().Single().Campaign!;
  using var memory=new FileCampaignStore(Path.Combine(Path.GetTempPath(),"marvel642-diagnostic-"+Guid.NewGuid().ToString("N")));
  // Diagnostic-only cloned authority. Original campaign gameplay and stored bytes remain untouched.
  string capability=new string('a',64);
  string verifier=Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(capability))).ToLowerInvariant();
  memory.Commit(original with {OwnerVerifier=verifier,Authorities=[..original.Authorities.Select((a,index)=>index == original.Authorities.Length-1 ? a with {Authorities=[..a.Authorities.Select((v,i)=>i == 0 ? v with {Verifier=verifier} : v)]} : a)]});
  var host=new CampaignHost(factory,memory,new MemorySessionStore());
  var saved=original.Save.Attempts[^1];
  var response=host.Exchange(EngineRequest.SyncGame("diagnostic-sync",saved.Session.Label,capability));
  Console.WriteLine($"sync error={response.Error} revision={response.Revision}");
  using var miner=JsonDocument.Parse(File.ReadAllText(Path.Combine(Path.GetDirectoryName(directory)!,"winner-528-1.json")));
  var first=miner.RootElement[6].GetProperty("steps")[0].Deserialize<JournalStep>()!;
  var result=host.Exchange(EngineRequest.ResolveGame("diagnostic-recovery",saved.Session.Label,capability,first.Decision.Resolve(response.Prompt!),response.Revision));
  Console.WriteLine($"resolve error={result.Error} revision={result.Revision}");
 }
}



