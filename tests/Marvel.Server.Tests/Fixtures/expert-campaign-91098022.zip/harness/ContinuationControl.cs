using System.Text.Json;
using Marvel.Server;
using Marvel.Protocol;
using Marvel.Session;
internal static class ContinuationControl {
 public static void Run(string directory) {
 var factory=DatasetGameFactory.Load(@"C:/Users/mggar/Source/marvel-lcg-630-predecessor");
 using var store=new FileCampaignStore(Path.Combine(directory,"campaigns"));
 var host=new CampaignHost(factory,store,new MemorySessionStore());
 using var access=JsonDocument.Parse(File.ReadAllText(Path.Combine(directory,"access.json")));var a=access.RootElement;
 var response=host.Exchange(EngineRequest.SyncGame("control-sync",a.GetProperty("game").GetString()!,a.GetProperty("capability").GetString()!));
 var saved=store.Load()[0].Campaign!.Save.Attempts[^1];var setup=saved.Setup;
 var local=factory.Create(new(setup.Scenario,setup.Heroes,setup.ModularSets,setup.Seed,setup.PlayerDecks,setup.Campaign)).Game;
 var policy=new Marvel.Sim.ActingPolicy(local.State.Facts,[new Marvel.Core.Random.MersenneTwister(528266).NextUInt32()]);
 foreach(var recorded in saved.Units.SelectMany(unit=>unit.Decisions)) {var offered=local.Pending!;var answer=policy.Answer(local);var actual=DurableDecision.From(DurableDecision.SimulationActor(offered,answer),offered,answer);if(CampaignSaveJson.Canonical(actual)!=CampaignSaveJson.Canonical(recorded.Decision))throw new Exception("policy diverged");_=local.Resolve(actual.Resolve(offered));policy.DecisionResolved();}
 var prompt=local.Pending!;var next=policy.Answer(local);var durable=DurableDecision.From(DurableDecision.SimulationActor(prompt,next),prompt,next);
 var request=EngineRequest.ResolveGame("verified-next-decision",a.GetProperty("game").GetString()!,a.GetProperty("capability").GetString()!,durable.Resolve(response.Prompt!),response.Revision);
 var expected=host.Exchange(request);if(expected.Error is not null)throw new Exception(expected.Error.Code);
 File.WriteAllBytes(Path.Combine(directory,"continuation-request.json"),EngineJson.Write(request));
 File.WriteAllBytes(Path.Combine(directory,"continuation-response.json"),EngineJson.Write(expected));
 File.WriteAllText(Path.Combine(directory,"continuation-decision.json"),JsonSerializer.Serialize(durable));
 Console.WriteLine("Original-runtime copy accepted next legal decision and recorded exact expected wire response");
 }
}

