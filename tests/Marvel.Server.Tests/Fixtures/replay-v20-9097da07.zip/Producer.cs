using System.IO.Compression;
using System.Text.Json;
using Marvel.Server;
using Marvel.Session;
using Marvel.Protocol;
using Marvel.Rules.Play;
var repo="C:/Users/mggar/Source/marvel-lcg-635-v20-predecessor";
var output=Path.Combine(Path.GetTempPath(),"marvel635-v20-artifacts");Directory.CreateDirectory(output);
var factory=DatasetGameFactory.Load(repo);
if(factory.Compatibility.ReplayContract!="engine-replay-v20")throw new Exception("wrong predecessor");
EngineResponse Check(EngineResponse r){if(r.Error is {} e)throw new Exception(e.Code+": "+e.Message);return r;}
var campaign=Path.Combine(output,"played");
ZipFile.ExtractToDirectory(Path.Combine(repo,"tests/Marvel.Server.Tests/Fixtures/played-campaign-91098022.zip"),campaign);
var fixture=Path.GetDirectoryName(Directory.GetFiles(campaign,"access.json",SearchOption.AllDirectories).Single())!;
using(var store=new FileCampaignStore(Path.Combine(fixture,"campaigns"))){
 var host=new CampaignHost(factory,store,new MemorySessionStore());
 using var access=JsonDocument.Parse(File.ReadAllText(Path.Combine(fixture,"access.json")));var a=access.RootElement;
 var sync=Check(host.Exchange(EngineRequest.SyncGame("v20-resume",a.GetProperty("game").GetString()!,a.GetProperty("capability").GetString()!)));
 File.WriteAllBytes(Path.Combine(fixture,"resumed-wire-response.json"),EngineJson.Write(sync));
 var owner=Check(host.Exchange(new(EngineProtocol.Version,"v20-owner",EngineProtocol.Campaign,a.GetProperty("id").GetString()!,Capability:a.GetProperty("owner").GetString()){Campaign=new("sync")}));
 File.WriteAllBytes(Path.Combine(fixture,"owner-wire-response.json"),EngineJson.Write(owner));
 var export=Check(host.Exchange(new(EngineProtocol.Version,"v20-export",EngineProtocol.Campaign,a.GetProperty("id").GetString()!,Capability:a.GetProperty("owner").GetString()){Campaign=new("export")}));
 File.WriteAllText(Path.Combine(fixture,"campaign-transfer.txt"),export.CampaignTransfer!);
 File.WriteAllBytes(Path.Combine(fixture,"campaign.json"),CampaignSaveJson.Write(store.Load().Single().Campaign!.Save));
 Console.WriteLine("Actual v20 migrated played campaign: "+store.Load().Single().Campaign!.Save.Attempts.Length+" attempts");
}
using(var store=new FileCampaignStore(Path.Combine(fixture,"campaigns"))){var host=new CampaignHost(factory,store,new MemorySessionStore());using var a=JsonDocument.Parse(File.ReadAllText(Path.Combine(fixture,"access.json")));Check(host.Exchange(EngineRequest.SyncGame("restart",a.RootElement.GetProperty("game").GetString()!,a.RootElement.GetProperty("capability").GetString()!)));Console.WriteLine("v20 campaign restart verified");}
var sessionDir=Path.Combine(output,"black-panther");Directory.CreateDirectory(sessionDir);
var sessions=new FileSessionStore(Path.Combine(sessionDir,"sessions"));
var engine=new EngineHost(factory,store:sessions);
var current=Check(engine.Exchange(EngineRequest.OpenGame("open","v20-bp",new("rhino",["black_panther"],null,700))));
var capability=current.Capability!;var options=new JsonSerializerOptions{PropertyNamingPolicy=JsonNamingPolicy.SnakeCaseLower};int count=0;
foreach(var line in File.ReadLines(Path.Combine(Path.GetTempPath(),"cap635-predecessor-bp-rhino.jsonl"))){using var doc=JsonDocument.Parse(line);var p=doc.RootElement;if(p.GetProperty("type").GetString()!="step")continue;
 var selector=p.GetProperty("decision").Deserialize<DecisionSelector>(options)!;
 var durable=new DurableDecision(DurableDecision.SimulationActor(current.Prompt!,selector),selector,p.GetProperty("targets").Deserialize<int[]>()!,p.GetProperty("resources").Deserialize<int[]>()!,p.GetProperty("values").Deserialize<Dictionary<string,long>>()!,p.GetProperty("allocations").Deserialize<ResourceAllocation[]>(options)!);
 current=Check(engine.Exchange(EngineRequest.ResolveGame("step-"+count++,"v20-bp",capability,durable.Resolve(current.Prompt!),current.Revision)));
}
File.WriteAllText(Path.Combine(sessionDir,"access.json"),JsonSerializer.Serialize(new{game="v20-bp",capability}));
File.WriteAllBytes(Path.Combine(sessionDir,"resumed-wire-response.json"),EngineJson.Write(Check(new EngineHost(factory,store:sessions).Exchange(EngineRequest.SyncGame("restart","v20-bp",capability)))));
Console.WriteLine("Actual v20 BP published and restarted: "+count+" decisions");
