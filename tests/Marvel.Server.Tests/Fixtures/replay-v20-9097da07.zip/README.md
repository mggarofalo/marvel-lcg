# Actual v20 predecessor fixtures

Produced with the unmodified committed runtime 9097da07 in the detached worktree
marvel-lcg-635-v20-predecessor. Producer.cs is the complete producer.

played: copied immutable played-campaign-91098022.zip (SHA256
1199392f3439fe89b6a21aa03d195df18bef1cc70f20dd65a998a2e32b29ffe8), then
production v20 CampaignHost verified and published its named migration. It resumed
all 13 attempts, including 786 original decisions, restarted from disk and exported
through the production API. Original v19 backups remain within the store. Owner
and current wire responses come from v20. The original continuation control is
retained unchanged; no gameplay values or authorities were relabelled manually.

black-panther: production v20 EngineHost opened Black Panther/Rhino standard seed
700 and accepted all 30 legal recorded decisions from the immutable 91098022
research trace (acting policy seed 13), then restarted from its real FileSessionStore.
The recorded outcomes come from v20. The v21 corrected zero-damage retaliation
must reject this history at the first affected decision, preserving the original
session, authority and manifest files. No fake terminal boards or outcomes.

Both fixtures were created outside test execution. Tests operate copies only.
No expert-campaign or nonzero-delay-counter claim is made.
